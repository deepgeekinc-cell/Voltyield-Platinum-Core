import json
import hashlib
from typing import Dict, Any, Optional, List

def canonicalize(data: Dict[str, Any]) -> bytes:
    return json.dumps(data, sort_keys=True, separators=(",", ":")).encode("utf-8")

class LedgerEntry:
    def __init__(self, payload: Dict[str, Any], prev_hash: Optional[str] = None):
        self.payload = payload
        self.entry_hash = hashlib.sha256(canonicalize(payload)).hexdigest()
        self.prev_hash = prev_hash
        self.chain_hash = hashlib.sha256(((prev_hash or "") + self.entry_hash).encode()).hexdigest()

class ForensicLedger:
    def __init__(self):
        self.entries = []
    
    def commit(self, payload: Dict[str, Any], idempotency_key: str):
        prev = self.entries[-1].chain_hash if self.entries else "GENESIS"
        entry = LedgerEntry(payload, prev)
        self.entries.append(entry)
        return entry
