import time
from fastapi import FastAPI, BackgroundTasks
from pydantic import BaseModel
from typing import List
from .ledger import ForensicLedger
from .regulatory import RegulatoryEngine

app = FastAPI(title="VoltYield Rail", version="2.0.0-ENTERPRISE")
ledger = ForensicLedger()
engine = RegulatoryEngine("v2026.2.0-STRICT")

class TelemetryBatch(BaseModel):
    fleet_id: str
    events: List[dict]

def process_event(event: dict):
    if "geo_hash" in event:
        ledger.commit(event, idempotency_key=str(time.time()))

@app.post("/ingest/telemetry")
async def ingest(batch: TelemetryBatch, tasks: BackgroundTasks):
    start = time.time()
    for event in batch.events:
        tasks.add_task(process_event, event)
    
    return {
        "status": "ACCEPTED", 
        "queued": len(batch.events),
        "latency_ms": round((time.time() - start) * 1000, 2),
        "ledger_height": len(ledger.entries)
    }

@app.get("/system/audit")
def audit():
    return {"status": "ONLINE", "ledger_blocks": len(ledger.entries), "engine": engine.version}
