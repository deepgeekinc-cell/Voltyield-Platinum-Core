import time, random, uuid, requests, concurrent.futures, sys

API_URL = "http://127.0.0.1:8000/ingest/telemetry"
TOTAL_REQUESTS = 500
BATCH_SIZE = 20
CONCURRENCY = 50

def generate_traffic():
    events = [{"asset_id": f"V-{random.randint(1000,9999)}", "geo_hash": "valid"} for _ in range(BATCH_SIZE)]
    return {"batch_id": str(uuid.uuid4()), "fleet_id": "FLEET-US-10k", "events": events}

def send_pulse():
    try: return requests.post(API_URL, json=generate_traffic(), timeout=2).status_code
    except: return 500

if __name__ == "__main__":
    print(f" VOLTYIELD | 10k FLEET LOAD TEST -> {API_URL}")
    print(f" [INJECTING] {TOTAL_REQUESTS * BATCH_SIZE} Events...")
    with concurrent.futures.ThreadPoolExecutor(max_workers=CONCURRENCY) as executor:
        futures = [executor.submit(send_pulse) for _ in range(TOTAL_REQUESTS)]
        for i, f in enumerate(concurrent.futures.as_completed(futures)):
             if i % 50 == 0: sys.stdout.write(f"\r [RAIL STATUS] Processed {i}/{TOTAL_REQUESTS} batches...")
    print("\n DONE.")
